const Discord = require('discord.js');
const client = new Discord.Client();
const ping = require('minecraft-server-util')
const prefix = '!'
client.login('ODIwMzU1NTA2NjM0NzUyMDQw.YEz9mg.vvqpE7dILUdr4kLam3DmsY2HGM4');

client.on('ready', () => {
  console.log(`${client.user.tag} is now alive pog!`);
});

